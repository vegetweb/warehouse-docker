<?php

$lang = array
(
	'unauthorised' => 'Unauthorised',
  'upgrade' => array('failure' => 'Upgrade failed. Transaction rollback done.  Please consult the error log file.'),
  'Unknown Exception: unauthorised' => 'An error occurred, possibly as a result of taking too long to fill in a data entry form, '.
      'using the browser\'s Back button and resubmitting a form twice or because the form is not configured correctly.'

);

?>
